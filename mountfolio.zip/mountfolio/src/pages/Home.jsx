// import { Canvas } from "@react-three/fiber";
// import { Suspense, useEffect, useRef, useState } from "react";

// import sakura from "../assets/sakura.mp3";
// import { HomeInfo, Loader } from "../components";
// import { soundoff, soundon } from "../assets/icons";
// import { Bird, Island, Plane, Sky } from "../models";

// const Home = () => {
//   const audioRef = useRef(new Audio(sakura));
//   audioRef.current.volume = 0.4;
//   audioRef.current.loop = true;

//   const [currentStage, setCurrentStage] = useState(1);
//   const [isRotating, setIsRotating] = useState(false);
//   const [isPlayingMusic, setIsPlayingMusic] = useState(false);

//   useEffect(() => {
//     if (isPlayingMusic) {
//       audioRef.current.play();
//     }

//     return () => {
//       audioRef.current.pause();
//     };
//   }, [isPlayingMusic]);

//   const adjustBiplaneForScreenSize = () => {
//     let screenScale, screenPosition;

//     // If screen width is less than 768px, adjust the scale and position
//     if (window.innerWidth < 768) {
//       screenScale = [1.5, 1.5, 1.5];
//       screenPosition = [0, -1.5, 0];
//     } else {
//       screenScale = [3, 3, 3];
//       screenPosition = [0, -4, -4];
//     }

//     return [screenScale, screenPosition];
//   };

//   const adjustIslandForScreenSize = () => {
//     let screenScale, screenPosition;

//     if (window.innerWidth < 768) {
//       screenScale = [0.9, 0.9, 0.9];
//       screenPosition = [0, -6.5, -43.4];
//     } else {
//       screenScale = [1, 1, 1];
//       screenPosition = [0, -6.5, -43.4];
//     }

//     return [screenScale, screenPosition];
//   };

//   const [biplaneScale, biplanePosition] = adjustBiplaneForScreenSize();
//   const [islandScale, islandPosition] = adjustIslandForScreenSize();

//   return (
//     <section className='w-full h-screen relative'>
//       <div className='absolute top-28 left-0 right-0 z-10 flex items-center justify-center'>
//         {currentStage && <HomeInfo currentStage={currentStage} />}
//       </div>

//       <Canvas
//         className={`w-full h-screen bg-transparent ${
//           isRotating ? "cursor-grabbing" : "cursor-grab"
//         }`}
//         camera={{ near: 0.1, far: 1000 }}
//       >
//         <Suspense fallback={<Loader />}>
//           <directionalLight position={[1, 1, 1]} intensity={2} />
//           <ambientLight intensity={0.5} />
//           <pointLight position={[10, 5, 10]} intensity={2} />
//           <spotLight
//             position={[0, 50, 10]}
//             angle={0.15}
//             penumbra={1}
//             intensity={2}
//           />
//           <hemisphereLight
//             skyColor='#b1e1ff'
//             groundColor='#000000'
//             intensity={1}
//           />

//           <Bird />
//           <Sky isRotating={isRotating} />
//           <Island
//             isRotating={isRotating}
//             setIsRotating={setIsRotating}
//             setCurrentStage={setCurrentStage}
//             position={islandPosition}
//             rotation={[0.1, 4.7077, 0]}
//             scale={islandScale}
//           />
//           <Plane
//             isRotating={isRotating}
//             position={biplanePosition}
//             rotation={[0, 20.1, 0]}
//             scale={biplaneScale}
//           />
//         </Suspense>
//       </Canvas>

//       <div className='absolute bottom-2 left-2'>
//         <img
//           src={!isPlayingMusic ? soundoff : soundon}
//           alt='jukebox'
//           onClick={() => setIsPlayingMusic(!isPlayingMusic)}
//           className='w-10 h-10 cursor-pointer object-contain'
//         />
//       </div>
//     </section>
//   );
// };

// export default Home;



// import { Canvas } from "@react-three/fiber";
// import { Suspense, useEffect, useRef, useState } from "react";

// import sakura from "../assets/sakura.mp3";
// import { HomeInfo, Loader } from "../components";
// import { soundoff, soundon } from "../assets/icons";
// import { Bird, Island, Plane, Sky } from "../models";

// const Home = () => {
//   const audioRef = useRef(new Audio(sakura));
//   audioRef.current.volume = 0.4;
//   audioRef.current.loop = true;

//   const [currentStage, setCurrentStage] = useState(1);
//   const [isRotating, setIsRotating] = useState(false);
//   const [isPlayingMusic, setIsPlayingMusic] = useState(false);

//   const [planePosition, setPlanePosition] = useState([0, -6.5, -43.4]);
//   const [planeRotation, setPlaneRotation] = useState([0, 1.5, 0]);
//   const [planeScale, setPlaneScale] = useState([1, 1, 1]);

//   useEffect(() => {
//     if (isPlayingMusic) {
//       audioRef.current.play();
//     }

//     return () => {
//       audioRef.current.pause();
//     };
//   }, [isPlayingMusic]);

//   const handlePlaneMovement = (e) => {
//   // Example: Move the plane along the X-axis based on mouse movement
//   const mouseX = e.clientX / window.innerWidth - 0.5;
//   setPlanePosition([mouseX * 10, -6.5, -43.4]);

//   // Example: Rotate the plane based on the Y-axis rotation
//   const rotationY = (mouseX * Math.PI) / 2; // Rotate up to 90 degrees
//   setPlaneRotation([0, rotationY, 0]);

//   // Example: Scale the plane based on the mouseY position
//   const mouseY = e.clientY / window.innerHeight;
//   const scale = 1 + mouseY * 2; // Scale between 1 and 3
//   setPlaneScale([scale, scale, scale]);
// };


//   return (
//     <section className='w-full h-screen relative'>
//       <div className='absolute top-28 left-0 right-0 z-10 flex items-center justify-center'>
//         {currentStage && <HomeInfo currentStage={currentStage} />}
//       </div>

//       <Canvas
//         className={`w-full h-screen bg-transparent ${
//           isRotating ? "cursor-grabbing" : "cursor-grab"
//         }`}
//         camera={{ near: 0.1, far: 1000 }}
//         onCreated={({ gl }) => {
//           gl.domElement.addEventListener("mousemove", handlePlaneMovement);
//         }}
//       >
//         <Suspense fallback={<Loader />}>
//           <Bird />
//           <Sky isRotating={isRotating} />
//           <Island
//             isRotating={isRotating}
//             setIsRotating={setIsRotating}
//             setCurrentStage={setCurrentStage}
//             position={[-2, -6.5, -43.4]}
//             rotation={[0.1, 4.7077, 0]}
//             scale={[1, 1, 1]}
//           />
//           <Plane
//             isRotating={isRotating}
//             position={planePosition}
//             rotation={planeRotation}
//             scale={planeScale}
//           />
//         </Suspense>
//       </Canvas>

//       <div className='absolute bottom-2 left-2'>
//         <img
//           src={!isPlayingMusic ? soundoff : soundon}
//           alt='jukebox'
//           onClick={() => setIsPlayingMusic(!isPlayingMusic)}
//           className='w-10 h-10 cursor-pointer object-contain'
//         />
//       </div>
//     </section>
//   );
// };

// export default Home;




import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useRef, useState } from "react";
import * as THREE from "three"; // Import THREE for material properties

import sakura from "../assets/sakura.mp3";
import { HomeInfo, Loader } from "../components";
import { soundoff, soundon } from "../assets/icons";
import { Bird, Island, Plane, Sky } from "../models";

const Home = () => {
  const audioRef = useRef(new Audio(sakura));
  audioRef.current.volume = 0.4;
  audioRef.current.loop = true;

  const [currentStage, setCurrentStage] = useState(1);
  const [isRotating, setIsRotating] = useState(false);
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);

  const [planePosition, setPlanePosition] = useState([0, -6.5, -43.4]);
  const [planeRotation, setPlaneRotation] = useState([0, 1.5, 0]);
  const [planeScale, setPlaneScale] = useState([1, 1, 1]);

  useEffect(() => {
    if (isPlayingMusic) {
      audioRef.current.play();
    }

    return () => {
      audioRef.current.pause();
    };
  }, [isPlayingMusic]);



  // const handlePlaneMovement = (e) => {
  //   const mouseX = e.clientX / window.innerWidth - 0.5;
  //   const mouseY = e.clientY / window.innerHeight;

  //   // Define island dimensions
  //   const islandRadius = 0.5; // Replace with the actual island radius
  //   const islandRotation = Math.PI / 8; // Replace with the actual island rotation

  //   // Calculate plane position along the edge of the island
  //   const planeX = islandRadius * Math.cos(islandRotation);
  //   const planeZ = islandRadius * Math.sin(islandRotation);

  //   setPlanePosition([planeX, -6.5, planeZ]);

  //   // Example: Rotate the plane based on the Y-axis rotation
  //   const rotationY = (mouseX * Math.PI) / 2; // Rotate up to 90 degrees
  //   setPlaneRotation([0, rotationY, 0]);

  //   // Example: Scale the plane based on the mouseY position
  //   const scale = 0.5 + mouseY * 0.5; // Scale between 1 and 3
  //   setPlaneScale([scale, scale, scale]);
  // };

const handlePlaneMovement = (e) => {
  const mouseX = e.clientX / window.innerWidth - 0.5;
  const mouseY = e.clientY / window.innerHeight;

  // Custom mathematical expression for plane position
  const islandRadius = 10; // Replace with the actual island radius
  const islandRotation = Math.PI / 16; // Replace with the actual island rotation

  // Calculate plane position using a custom expression
  const planeX = Math.sin(mouseX * Math.PI) * islandRadius * Math.cos(islandRotation);
  const planeZ = Math.cos(mouseY * Math.PI) * islandRadius * Math.sin(islandRotation);

  setPlanePosition([planeX, -6.5, planeZ]);  // Adjust the y-coordinate as needed

  // Example: Rotate the plane based on the Y-axis rotation
  const rotationY = (mouseX * Math.PI) / 2; // Rotate up to 90 degrees
  setPlaneRotation([0, rotationY, 0]);

  // Example: Scale the plane based on the mouseY position
  const scale = 0.1 + mouseY * 0.15; // Scale between 1 and 3
  setPlaneScale([scale, scale, scale]);
};



  return (
    <section className='w-full h-screen relative'>
      <div className='absolute top-28 left-0 right-0 z-10 flex items-center justify-center'>
        {currentStage && <HomeInfo currentStage={currentStage} />}
      </div>

      <Canvas
        className={`w-full h-screen bg-transparent ${
          isRotating ? "cursor-grabbing" : "cursor-grab"
        }`}
        camera={{ near: 0.1, far: 1000 }}
        onCreated={({ gl }) => {
          gl.domElement.addEventListener("mousemove", handlePlaneMovement);
        }}
      >
        <Suspense fallback={<Loader />}>
          {/* Adjusted lighting */}
          <directionalLight position={[5, 5, 5]} intensity={2} />
          <ambientLight intensity={0.5} />
          <pointLight position={[0, 0, 0]} intensity={1} />
          <spotLight position={[0, 50, 10]} angle={0.15} penumbra={1} intensity={2} />
          <hemisphereLight skyColor='#b1e1ff' groundColor='#000000' intensity={1} />

          <Bird />
          <Sky isRotating={isRotating} />
          <Island
            isRotating={isRotating}
            setIsRotating={setIsRotating}
            setCurrentStage={setCurrentStage}
            position={[-2, -6.5, -43.4]}
            rotation={[0.1, 4.7077, 0]}
            scale={[1, 1, 1]}
          />
          <Plane
            isRotating={isRotating}
            position={planePosition}
            rotation={planeRotation}
            scale={planeScale}
          />
        </Suspense>
      </Canvas>

      <div className='absolute bottom-2 left-2'>
        <img
          src={!isPlayingMusic ? soundoff : soundon}
          alt='jukebox'
          onClick={() => setIsPlayingMusic(!isPlayingMusic)}
          className='w-10 h-10 cursor-pointer object-contain'
        />
      </div>
    </section>
  );
};

export default Home;
