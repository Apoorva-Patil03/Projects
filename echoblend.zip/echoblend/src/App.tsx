import { Routes,Route } from 'react-router-dom'

import SigninForm from './_auth/forms/SigninForm'
import SignupForm from './_auth/forms/SignupForm'
import { Home } from './_root/pages' //here in bracket all pages will be imported 
import AuthLayout from './_auth/AuthLayout'
import RootLayout from './_root/RootLayout'
import './globals.css'

const App = () =>{
  return(
    <main className='flex h-screen'> 
    <Routes>
      {/*public routes that everyone will be able to see like signup or signin*/}
      <Route element={<AuthLayout />}>     {/* not self closing routes becuase it allows to receive an element called authlayout and we can place additional elements or pages that are going to appear there*/}
         <Route path='/sign-in' element={<SigninForm/>}/> 
          {/* self closing routes */}
          {/* render an element of sign in form it's going to be a self-closing element now of course this is a page or a component which we have to import inside of here */}
         <Route path='/sign-in' element={<SignupForm/>}/>
      </Route>

      {/* here we use the layout but then immediately place the pages using that layout  */}
      
      {/*private routes that everyone will not be able to see if only u r signed-in*/}
      <Route element={<RootLayout/>}>    {/* not self closing routes becuase it allows to receive an element called rootlayout and we can place additional elements or pages that are going to appear there like we can place all of the home routes right here*/}
       <Route index element={<Home/>}/>   
       {/* self closing routes */}
       {/*  giving it an index this means that this is the starting page and then the element is going to be a home component  */}
      </Route>
      
    </Routes>
    </main>
  )
}
export default App

//h-screen : height:100vh 100% of screen
//_auth folder is for public routes
//_root folder is for private routes
//this wraps both the signinform and signupform files
//And all the components like sidebars,etc. which would be included in app wil be in pages folder 
//we made index.ts file for importing all .tsx files in more cleaner way through it 