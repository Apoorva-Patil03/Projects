// import React, { useEffect, useRef } from "react";
// import { useGLTF, useAnimations } from "@react-three/drei";

// import planeScene from "../assets/3d/basic_plane.glb";

// // 3D Model from: https://sketchfab.com/3d-models/stylized-ww1-plane-c4edeb0e410f46e8a4db320879f0a1db
// const Plane = ({ isRotating, ...props }) => {
//   const ref = useRef();

//   // Load the 3D model and its animations
//   const { scene, animations } = useGLTF(planeScene);

//   // Get animation actions associated with the plane
//   const { actions } = useAnimations(animations, ref);

//   // Use an effect to control the plane's animation based on 'isRotating'
//   // Note: Animation names can be found on the Sketchfab website where the 3D model is hosted.
//   useEffect(() => {
//     // Ensure the animation exists before attempting to play or stop
//     if (actions["Take 001"]) {
//       if (isRotating) {
//         actions["Take 001"].play();
//       } else {
//         actions["Take 001"].stop();
//       }
//     }
//   }, [actions, isRotating]);

//   return (
//     <mesh {...props} ref={ref}>
//       {/*  use the primitive element when you want to directly embed a complex 3D model or scene */}
//       <primitive object={scene} />
//     </mesh>
//   );
// };

// // Preload the 3D model to ensure it's ready when the component is mounted
// useGLTF.preload("/basic_plane.glb");

// export { Plane };


import React, { useEffect, useRef } from "react";
import { useGLTF, useAnimations } from "@react-three/drei";

import planeScene from "../assets/3d/basic_plane.glb";

const Plane = ({ isRotating, ...props }) => {
  const ref = useRef();
  const { scene, animations } = useGLTF(planeScene);
  const { actions } = useAnimations(animations, ref);

  useEffect(() => {
    if (actions["Take 001"]) {
      isRotating ? actions["Take 001"].play() : actions["Take 001"].stop();
    }
  }, [actions, isRotating]);

  useEffect(() => {
    if (ref.current) {
      // Explicitly set the desired position for the plane
      ref.current.position.x = 5;
      ref.current.position.y = 0;
      ref.current.position.z = 10;

      // Set the original size (scale) of the plane
      ref.current.scale.set(1, 1, 1); // Assuming the original size is (1, 1, 1)
    }
  }, []);

  return (
    <mesh {...props} ref={ref}>
      <primitive object={scene} />
    </mesh>
  );
};

useGLTF.preload("/basic_plane.glb");

export { Plane };
